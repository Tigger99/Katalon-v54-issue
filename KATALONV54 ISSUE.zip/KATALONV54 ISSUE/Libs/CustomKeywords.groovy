
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject


def static "tools.CreateVWemail.myCreateVWemail"() {
    (new tools.CreateVWemail()).myCreateVWemail()
}

def static "tools.QAMRefNumber.myRefNumber"() {
    (new tools.QAMRefNumber()).myRefNumber()
}

def static "tools.simplePrint.mySimplePrint"(
    	String msg	) {
    (new tools.simplePrint()).mySimplePrint(
        	msg)
}

def static "tools.QARefNumber.myRefNumber"() {
    (new tools.QARefNumber()).myRefNumber()
}

def static "tools.ClickUsingJava.JavaClick"(
    	TestObject to	
     , 	int timeout	) {
    (new tools.ClickUsingJava()).JavaClick(
        	to
         , 	timeout)
}

def static "tools.QAMClientFirstName.myClientFirstName"() {
    (new tools.QAMClientFirstName()).myClientFirstName()
}

def static "tools.uploadFiles.uploadFile"(
    	TestObject to	
     , 	String filePath	) {
    (new tools.uploadFiles()).uploadFile(
        	to
         , 	filePath)
}

def static "tools.JavaScript.executeJavaScript"(
    	String javascript	) {
    (new tools.JavaScript()).executeJavaScript(
        	javascript)
}

def static "tools.Q6J_Account_Number.newAccountNum"() {
    (new tools.Q6J_Account_Number()).newAccountNum()
}

def static "tools.pdfReader.ReadPDF"(
    	String PDFURL	) {
    (new tools.pdfReader()).ReadPDF(
        	PDFURL)
}

def static "tools.JavaThreadSleep.myThreadSleep"(
    	long milliseconds	) {
    (new tools.JavaThreadSleep()).myThreadSleep(
        	milliseconds)
}

def static "tools.ClientLastName.myClientLastName"() {
    (new tools.ClientLastName()).myClientLastName()
}

def static "tools.CreateQIEemail.myCreateQIEemail"() {
    (new tools.CreateQIEemail()).myCreateQIEemail()
}

def static "tools.CreateQTemail.myCreateQTemail"() {
    (new tools.CreateQTemail()).myCreateQTemail()
}

def static "tools.ClientFirstName.myClientFirstName"() {
    (new tools.ClientFirstName()).myClientFirstName()
}

def static "tools.Q5J_Account_Number.newAccountNum"() {
    (new tools.Q5J_Account_Number()).newAccountNum()
}

def static "tools.QAClientFirstName.myClientFirstName"() {
    (new tools.QAClientFirstName()).myClientFirstName()
}
