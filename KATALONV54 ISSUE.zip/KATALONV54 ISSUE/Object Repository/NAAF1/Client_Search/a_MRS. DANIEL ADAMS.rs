<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_MRS. DANIEL ADAMS</name>
   <tag></tag>
   <elementGuidId>18b3dd43-1dd2-4ed1-a807-3a5997ff2a53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[count(. | //*[@href = '/qadvisor_onlineapp/retrievePendingClientInfo.do?value.applicationLoadId=32135&amp;filterDiscretionary=true']) = count(//*[@href = '/qadvisor_onlineapp/retrievePendingClientInfo.do?value.applicationLoadId=32135&amp;filterDiscretionary=true'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/qadvisor_onlineapp/retrievePendingClientInfo.do?value.applicationLoadId=32135&amp;filterDiscretionary=true</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>MRS. DANIEL ADAMS
                                     
                                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;q_container&quot;)/form[1]/table[@class=&quot;pageContainer&quot;]/tbody[1]/tr[1]/td[@class=&quot;contentSection&quot;]/table[@class=&quot;contents&quot;]/tbody[1]/tr[2]/td[1]/table[1]/tbody[1]/tr[5]/td[1]/table[1]/tbody[1]/tr[2]/td[1]/a[1]</value>
   </webElementProperties>
</WebElementEntity>
