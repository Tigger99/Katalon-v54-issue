<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Create New Prospective Clien</name>
   <tag></tag>
   <elementGuidId>bdf39b0d-c3eb-4b08-abc6-e87d1db90e74</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/qadvisor_onlineapp/createProspectiveClient.do</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create New Prospective Client</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;applicationForm&quot;)/table[@class=&quot;pageContainer&quot;]/tbody[1]/tr[1]/td[@class=&quot;contentSection&quot;]/table[@class=&quot;contents&quot;]/tbody[1]/tr[2]/td[@class=&quot;contentSection&quot;]/table[@class=&quot;listTable&quot;]/tbody[1]/tr[5]/td[2]/a[1]</value>
   </webElementProperties>
</WebElementEntity>
