<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_VCE9M</name>
   <tag></tag>
   <elementGuidId>1258abc8-df44-4f09-82f6-94a29ec609be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//b[count(. | //*[starts-with(.,'#VCE9M')]) = count(//*[starts-with(.,'#VCE9M')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>starts with</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>#V</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;applicationForm&quot;)/table[@class=&quot;pageContainer&quot;]/tbody[1]/tr[1]/td[@class=&quot;contentSection&quot;]/table[@class=&quot;contents&quot;]/tbody[1]/tr[2]/td[@class=&quot;contentSection&quot;]/table[1]/tbody[1]/tr[1]/td[2]/b[1]</value>
   </webElementProperties>
</WebElementEntity>
