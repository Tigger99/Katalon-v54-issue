<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Search.Btn</name>
   <tag></tag>
   <elementGuidId>2a851484-86d3-41d0-b861-42541ba72c94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#container > form > div:nth-child(2) > table > tbody > tr:nth-child(14) > td:nth-child(2) > input:nth-child(1)</value>
   </webElementProperties>
</WebElementEntity>
