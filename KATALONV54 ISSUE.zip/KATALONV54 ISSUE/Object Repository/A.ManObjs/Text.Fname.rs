<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Text.Fname</name>
   <tag></tag>
   <elementGuidId>83ebfe19-0dbb-44cd-a76a-680857b5b64a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#container > form > div:nth-child(2) > table > tbody > tr:nth-child(1) > td:nth-child(2) > input[type=&quot;text&quot;]</value>
   </webElementProperties>
</WebElementEntity>
