<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>1stPage</name>
   <tag></tag>
   <elementGuidId>e24230dc-d943-4fd6-9969-f7d95e34836d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;collapse129150&quot;]/div/div[1]/div[12]/ul/li[1]/a</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#collapse129150 > div > div.div-questions-section > div.pagination.pagination-small > ul > li:nth-child(1) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
