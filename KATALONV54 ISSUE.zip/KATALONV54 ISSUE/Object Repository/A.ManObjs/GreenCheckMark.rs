<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GreenCheckMark</name>
   <tag></tag>
   <elementGuidId>b5bc96e3-ce2d-451c-a109-281fb0bec99a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;tb-investable-assets-summary&quot;]/tbody/tr[5]/td[2]/div[2]/div[2]/div/p/div[1]/table/tbody/tr/td[3]/button[1]/i</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#tb-investable-assets-summary > tbody > tr:nth-child(5) > td.text-left.td-accounts-account > div.popover.fade.top.in.input-error > div.popover-inner > div > p > div:nth-child(2) > table > tbody > tr > td.text-center > button.btn.btn-mini.btn-icon.btn-save-benef > i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
