<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Investor.Search</name>
   <tag></tag>
   <elementGuidId>a61017bb-325f-4f69-9f6b-735b7bf159ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>#ccenter_container > table > tbody > tr > td > div.cc_container > table > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td.bodytext > div > ul > li:nth-child(1) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>#ccenter_container > table > tbody > tr > td > div.cc_container > table > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td.bodytext > div > ul > li:nth-child(1) > a</value>
   </webElementProperties>
</WebElementEntity>
