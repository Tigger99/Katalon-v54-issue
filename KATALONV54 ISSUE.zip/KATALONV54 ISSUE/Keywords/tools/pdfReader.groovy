package tools
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.text.PDFTextStripper
import org.testng.Assert
import com.kms.katalon.core.annotation.Keyword

//###########################################################################
//ADDING the ReadPDF() CUSTOM KEYWORD TO ANY PROJECT
//First add the pdfbox JAR file to the test project
//1. Open https://pdfbox.apache.org/download.cgi
//2. Download the latest pdfbox JAR file (e.g., pdfbox-2.0.8.jar)
//3. Start Katalon & select "Project > Settings > External Libraries"
//4. Click Add & add the pdfbox-2.0.8.jar libraries to the project & click Apply
//5. Add the following ReadPDF() method custom keyword
//6. After adding the custom keyword press CTRL + SHIFT + O to add the needed libraries
//###########################################################################
//USAGE:
// Call the keyword & pass the PDF URL as the keyword's input
// Use Assert.assertTrue() to verify the results on the PDF
//###########################################################################

@Keyword
def ReadPDF(String PDFURL)
{
	URL TestURL = new URL(PDFURL);
	BufferedInputStream bis = new BufferedInputStream(TestURL.openStream());
	PDDocument doc = PDDocument.load(bis);
	String pdfText = new PDFTextStripper().getText(doc);
	doc.close();
	bis.close();
	println(pdfText);
	Assert.assertTrue(pdfText.contains("Open the setting.xml, you can see it is like this:"));
	Assert.assertTrue(pdfText.contains("Please add the following sentence in setting.xml before"));
	Assert.assertTrue(pdfText.contains("You can see that I have modified the setting.xml, and if open the file in IE, it is like this:"));
	println "See Keywords > Tools > pdfReader for Assertions";
	println "PDF IS GOOD TO GO...\r";
}