package tools
import java.util.concurrent.ThreadLocalRandom
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import internal.GlobalVariable
import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

public class SINGenerator {
	public String getSINAsString() {

		boolean valid = false;

		while(valid == false) {

			String SIN = "";
			for (int i = 0; i < 9; i++)
				SIN += ThreadLocalRandom.current().nextInt(1, 9 + 1);

			int theSIN = Integer.valueOf(SIN);

			//System.out.println("The SIN: " + theSIN );

			boolean evenDigit = false; //alternates between true and false
			int sum = 0; //accumulates the sum of the digits (as modified)

			while (theSIN > 0) {
				int nextDigit = theSIN % 10; //grab the last digit
				theSIN = theSIN / 10; //discard that digit
				if(evenDigit) {
					//double it, then add the two digits of the result
					nextDigit = 2*nextDigit;
					nextDigit = (nextDigit/10)+(nextDigit%10);
				} // if(evenDigit)
				sum = sum + nextDigit;
				evenDigit = !evenDigit; //toggle the flag each time
			} // end while
			if (0 == sum % 10) {
				//System.out.println("That is a valid S.I.N.");
				return SIN;
			} else {
				//System.out.println("That is not a valid S.I.N.");
			}
		}
	}
}
