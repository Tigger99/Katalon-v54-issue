package tools
import org.openqa.selenium.JavascriptExecutor
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory

// usage example
// ((JavascriptExecutor) DriverFactory.getWebDriver()).executeScript(“myjavascript”)
// https://forum.katalon.com/discussion/2008/execute-javascript

public class JavaScript {
	@Keyword
	def executeJavaScript(String javascript) {
		((JavascriptExecutor) DriverFactory.getWebDriver()).executeScript(javascript)
	}
}